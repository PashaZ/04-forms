# react-18

- Основные концепции: store, state, actions, action creators, reducers
- Feature based структура файлов и папок
  - Создаём и настраиваем хранилище (store)
  - Готовим экшены (действия, actions) и фабрики
  - Пишем редюсер
- Связываем компоненты и хранилище.
  - Пакет react-redux.
  - Компонент Provider
  - Функция connect(mapStateToProps, mapDispatchToProps)
- Redux DevTools
- Композиция редюсеров с combineReducers
