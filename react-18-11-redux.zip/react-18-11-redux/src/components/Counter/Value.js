import React from 'react';

const Value = ({ value }) => <span className="Counter__value">{value}</span>;

export default Value;
