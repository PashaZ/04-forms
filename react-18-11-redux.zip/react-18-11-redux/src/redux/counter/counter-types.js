const INCREMENT = 'counter/Increment';
const DECREMENT = 'counter/Decrement';

export default { INCREMENT, DECREMENT };
