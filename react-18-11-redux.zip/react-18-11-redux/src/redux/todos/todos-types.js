export default {
  ADD: 'todos/add',
  DELETE: 'todos/delete',
  TOGGLE_COMPLETED: 'todos/toggleCompleted',
  CHANGE_FILTER: 'todos/changeFilter',
};
