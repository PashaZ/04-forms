import React from 'react';
import Counter from '../components/Counter';

export default function CounterView() {
  return <Counter />;
}
